#!/bin/bash

sleep 60
node $HOME/sysinfo/update-ip-lightsail.js -k __CF_API_KEY__ \
        -e youremail@gmail.com -z __ZONE_ID__ \
        -r __RECORD_ID__ \
        -n __DOMAIN__ >> $HOME/update-ip.log 2>&1
