#!/bin/sh

set -x

# Domain name used for the operation
if [[ -z "${DOMAIN}" ]]; then
  echo "DOMAIN var doesn't exist."
  exit 1
fi

# Installing various useful tools on the VPS
sudo apt update && sudo apt upgrade -y
sudo apt install -y certbot net-tools geoip-bin curl unzip wget \
  tmux geoip-bin geoip-database at sed iftop nginx uuid-runtime

curl -sL https://deb.nodesource.com/setup_20.x -o /tmp/nodesource_setup.sh
sudo bash /tmp/nodesource_setup.sh
sudo apt-get install -y nodejs
node -v

UUID=$(uuidgen)

sudo sed -e "s/__DOMAIN__/${DOMAIN}/g" -i ./config.json
sudo sed -e "s/__UUID__/${UUID}/g" -i ./config.json

sudo cp nginx.conf /etc/nginx/
sudo systemctl restart nginx
sudo systemctl status --no-pager nginx
sleep 5

sudo certbot certonly --no-eff-email --non-interactive --standalone \
  --preferred-challenges http --agree-tos --email test@gmail.com -d ${DOMAIN}

sudo cp update-ip-lightsail.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable update-ip-lightsail.service
sudo systemctl status --no-pager update-ip-lightsail.service
sleep 5

sudo mkdir -p /usr/local/etc/xray/
sudo cp ./config.json /usr/local/etc/xray/config.json
sudo bash install-release.sh install -u root -f --version 1.8.23

sudo cp iran.dat dlc.dat /usr/local/bin/

sleep 10
sudo systemctl daemon-reload
sudo systemctl enable xray.service
sudo systemctl restart xray.service
sudo systemctl status --no-pager xray.service
sleep 10

cat <<EOT | sudo tee -a /etc/sysctl.conf
net.ipv4.tcp_keepalive_time=600
net.ipv4.tcp_keepalive_probes=6
net.ipv4.tcp_keepalive_intvl=10
net.ipv4.tcp_retries2=30
net.ipv4.tcp_fastopen=3
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
net.core.netdev_max_backlog=30000
net.ipv4.tcp_mem=1528512 2038016 8388608
net.core.rmem_max=16777216
net.core.wmem_max=16777216
net.ipv4.tcp_rmem=4096 87380 16777216
net.ipv4.tcp_wmem=4096 65536 16777216
net.ipv4.tcp_max_syn_backlog=1000
net.core.somaxconn=10000
net.ipv4.tcp_max_tw_buckets=10000
net.ipv4.tcp_no_metrics_save=1
net.ipv4.ip_local_port_range=10000 60999
EOT

cat <<EOT | sudo tee -a /etc/security/limits.conf
* soft nproc 10000
* hard nproc 10000
* soft nofile 10000
* hard nofile 10000
EOT

sleep 5

sudo sync -f

set +x

echo "********** v2ray config ************"
echo "When you copy this vless address, make sure there is no line breakage in the config."
echo ""
echo "vless://${UUID}@${DOMAIN}:443?security=tls&encryption=none&headerType=none&fp=chrome&type=tcp&flow=xtls-rprx-vision&sni=${DOMAIN}#internet"
