const axios = require('axios');
const yargs = require('yargs/yargs');
const { hideBin } = require('yargs/helpers');

const LIGHTSAIL_METADATA_URL = 'http://169.254.169.254/latest/meta-data/public-ipv4';

async function getLightsailInstancePublicIP() {
  try {
    const response = await axios.get(LIGHTSAIL_METADATA_URL);
    return response.data;
  } catch (error) {
    console.error('Error getting Lightsail instance IP:', error);
    return null;
  }
}

async function updateCloudflareDNS(ipAddress, options) {
  try {
    await axios.patch(
      `https://api.cloudflare.com/client/v4/zones/${options.zoneId}/dns_records/${options.recordId}`,
      {
        type: options.recordType,
        name: options.recordName,
        content: ipAddress,
      },
      {
        headers: {
          'Authorization': `Bearer ${options.apiKey}`,
          'Content-Type': 'application/json',
        },
      },
    );
    console.log('DNS record updated successfully');
  } catch (error) {
    console.error('Error updating Cloudflare DNS record:', error);
  }
}

const argv = yargs(hideBin(process.argv))
  .option('apiKey', {
    alias: 'k',
    type: 'string',
    description: 'Your Cloudflare API key',
    demandOption: true,
  })
  .option('email', {
    alias: 'e',
    type: 'string',
    description: 'Your Cloudflare email address',
    demandOption: true,
  })
  .option('zoneId', {
    alias: 'z',
    type: 'string',
    description: 'Your Cloudflare zone ID',
    demandOption: true,
  })
  .option('recordId', {
    alias: 'r',
    type: 'string',
    description: 'Your Cloudflare DNS record ID',
    demandOption: true,
  })
  .option('recordName', {
    alias: 'n',
    type: 'string',
    description: 'Your Cloudflare DNS record name',
    demandOption: true,
  })
  .option('recordType', {
    alias: 't',
    type: 'string',
    description: 'Your Cloudflare DNS record type (e.g., A, CNAME)',
    default: 'A',
  })
  .help()
  .alias('help', 'h')
  .argv;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
  let tries = 0;
  while (tries <= 5) {
    try {
      const ipAddress = await getLightsailInstancePublicIP();
      if (ipAddress) {
        console.log(`New IP Address: ${ipAddress}`);
        await updateCloudflareDNS(ipAddress, {
          apiKey: argv.apiKey,
          email: argv.email,
          zoneId: argv.zoneId,
          recordId: argv.recordId,
          recordName: argv.recordName,
          recordType: argv.recordType,
        });
        process.exit(0);
      } else {
        console.error('Failed to get Lightsail instance IP address');
      }
    } catch (e) {
      console.error(e);
    }
    tries++;
    await sleep(5000);
  }
  process.exit(1);
})();
